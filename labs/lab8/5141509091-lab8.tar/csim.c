/**************************
 *                        *
 *  name: 周雪振           *
 *                        *
 *  ID: 5141509091        *
 *                        *
 **************************
*/


#include "cachelab.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define GETBIT(mask, adr) ((mask)&(adr))

/* RunMode为命令行参数的形式类型，分为HELP，VERBOSE， GENERAL， ERROR*/
typedef enum{HELP, VERBOSE, GENERAL, ERROR} RunMode;

/* cache中的行数据结构 */
typedef struct{
    //valid_bit>0, 则为hit， valid_bit越大表示越久没有访问
    long valid_bit;  
    long tag_bit;
} cache_line;

/* s, E, b分别为cache的参数：
 * s为S=2**s， 中的s, S为cache的集合数
 * E为每个集合中的行数
 * b为每个block的大小
*/
static int s, E, b;
/* fp为trace文件指针 */
static FILE* fp;
/* hit_cnt, miss_cnt, eviction_cnt分别用来统计hit, miss, eviction的次数 */
static int hit_cnt, miss_cnt, eviction_cnt;
/* tag_mask, set_mask分别为tag_bit和set_bit的掩码 */
static long tag_mask, set_mask;

/* ParseArg(): 解析命令行参数 */
RunMode ParseArg(int argc, char **argv);

/* printHelp(): 查看命令行帮助信息 */
void printHelp();

/* init(): 初始化cache参数和trace文件 */
int init(char* sNum, char* ENum, char* bNum, char *file);

/* cache模拟 */
void cacheSim(RunMode);

/*
 * main():主函数
 * 1. 解析命令行参数
 * 2. 调用cache simulator
 * 3. 打印结果 
*/
int main(int argc, char ** argv)
{
    /* 解析命令行参数 */
    RunMode rm=ParseArg(argc, argv);
    /* -h 模式，打印命令行帮助信息 */
    if(rm==HELP){
        printHelp();
        return 0;
    /* -v 模式，输出模拟过程和最后结果*/
    }else if(rm==VERBOSE){
        /* 初始化cache参数和trace文件 */
        if(init(argv[3], argv[5],argv[7], argv[9])==0){
            printf("%s: No such file or directory\n", argv[9]);
            return 0;
        }
    /* 一般模式，只输出最后结果 */
    }else if(rm==GENERAL){
        /* 初始化cache参数和trace文件 */
        if(init(argv[2], argv[4], argv[6], argv[8])==0){
            printf("%s: No such file or directory\n", argv[8]);
            return 0;
        }
    /* 命令行参数不匹配，打印错误信息和帮助信息 */
    }else{
        printf("./csim: Missing required command line argument\n");
        printHelp();
        return 0;
    }
    /* 调用cache simulator */
    cacheSim(rm);
    /* 关闭文件（在init中打开） */
    fclose(fp);
    /* 打印最终结果 */
    printSummary(hit_cnt, miss_cnt, eviction_cnt);
    return 0;
}


/*
 * 初始化cache参数和trace文件
*/
int init(char* sNum, char* ENum, char* bNum, char *file){
    s=atoi(sNum);                         //初始化set bit
    E=atoi(ENum);                         //初始化 E
    b=atoi(bNum);                         //初始化block bit
    tag_mask=((long)(-1))<<(b+s);         //初始化tag_bit的掩码
    set_mask=(((long)(-1))<<b)^tag_mask;  //初始化set_bit的掩码
    fp=fopen(file, "r");                  //初始化trace文件
    if(!fp) return 0;
    return 1;
}


/*
 * 解析命令行参数
*/
RunMode ParseArg(int argc, char **argv){
    /* ./scim -h */
    if(argc==2){                     
        if(strcmp(argv[1], "-h")!=0)
            return ERROR;
        return HELP;
    }
    /* ./scim -v -s <num> -E <num> -b <num> -t <*.trace> */
    if(argc==10){
        if(strcmp(argv[1], "-v")!=0)
            return ERROR;
        if(strcmp(argv[2], "-s")!=0)
            return ERROR;
        if(strspn(argv[3], "0123456789")!=strlen(argv[3]))
            return ERROR;
        if(strcmp(argv[4], "-E")!=0)
            return ERROR;
        if(strspn(argv[5], "0123456789")!=strlen(argv[5]))
            return ERROR;
        if(strcmp(argv[6], "-b")!=0)
            return ERROR;
        if(strspn(argv[7], "0123456789")!=strlen(argv[7]))
            return ERROR;
        if(strcmp(argv[8], "-t")!=0)
            return ERROR;
        return VERBOSE;
    }
    /* ./scim -s <num> -E <num> -b <num> -t <*.trace> */
    if(argc==9){
        if(strcmp(argv[1], "-s")!=0)
            return ERROR;
        if(strspn(argv[2], "0123456789")!=strlen(argv[2]))
            return ERROR;
        if(strcmp(argv[3], "-E")!=0)
            return ERROR;
        if(strspn(argv[4], "0123456789")!=strlen(argv[4]))
            return ERROR;
        if(strcmp(argv[5], "-b")!=0)
            return ERROR;
        if(strspn(argv[6], "0123456789")!=strlen(argv[6]))
            return ERROR;
        if(strcmp(argv[7], "-t")!=0)
            return ERROR;
        return GENERAL;
    }
    return ERROR;
}

/*
* 打印帮助信息
*/
void printHelp(){
    printf("Usage: ./csim [-hv] -s <num> -E <num> -b <num> -t <file>\n");
    printf("Options:\n");
    printf("  -h         Print this help messae.\n");
    printf("  -v         Optional verbose flag.\n");
    printf("  -s <num>   Number of set index bits.\n");
    printf("  -E <num>   Number of lines per set\n");
    printf("  -b <num>   Number of block offset bits.\n");
    printf("  -t <file>  Trace file.\n");
    printf("\nExamples:\n");
    printf("  linux>  ./csim -s 4 -E 1 -b 4 -t traces/yi.trace\n");
    printf("  linux>  ./csim -v -s 8 -E 2 -b 4 -t traces/yi.trace\n");
}

/* initCache(): 初始化cache */
void initCache(cache_line (*)[E]);

/*cacheLoad(): cache操作 */
void cacheOption(cache_line (*)[E], RunMode, long);

/* pow(): 计算2的幂次 */
int power(int);

/*
 * cacheSim(): cache simulator
 * cahce组织为一个cache_line的二位数组
*/
void cacheSim(RunMode rm){
    /* 初始化cache */
    cache_line (*cache)[E]=(cache_line (*)[E])malloc(sizeof(cache_line)*power(s)*E);
    initCache(cache);
    /* 以下变量用来存储trace文件读取的数据 */
    char op[2];
    long adr;
    int size;
    char ch;
    /* 逐行处理trace文件 */
    fscanf(fp, "%s", op);
    while(feof(fp)==0){
        fscanf(fp, "%lx%c%d",&adr, &ch, &size);
        /* 不处理instruction的操作 */
        if(strcmp(op,"I")!=0){
            /* -v模式打印过程信息，程序中相同的语句作用相同*/
            if(rm==VERBOSE)printf("%s %lx,%d", op, adr, size);
            /* 处理load和store */
            if(strcmp(op, "L")==0 || strcmp(op, "S")==0){
                cacheOption(cache, rm, adr);
                if(rm==VERBOSE)printf("\n");
            }
            /* 处理modify, 分解为load和store，有两次cache option */
            else if(strcmp(op, "M")==0){
                cacheOption(cache, rm, adr);
                cacheOption(cache, rm, adr);
                if(rm==VERBOSE)printf("\n");
            }
        }
        fscanf(fp, "%s", op);
    }
    free(cache);
} 

/*
 * 初始化cache，每个cache_line的valid_bit置0
*/
void initCache(cache_line (*cache) [E]){
    for(int i=0;i<s;i++){
        for(int j=0;j<E;j++){
           cache[i][j].valid_bit=0; 
        }
    }
}

/*
 * 计算幂次
*/
int power(int y){
    if(y==0)return 1;
    int t=power(y/2);
    if(y%2==0)return t*t;
    return t*t*2;
}

/*
 * accessCache(): 访问cache set
*/
cache_line *accessCache(cache_line *cset, long tag_bit){
    /* 遍历cache中的cache_line,找到对应的cache_line */
    for(int i=0; i<E; i++){
        if(cset[i].valid_bit>0 && cset[i].tag_bit==tag_bit)
            return &cset[i];
    }
    /* cache miss，返回空指针 */
    return NULL;
}

/*
 * setValidBit(): 设置一个cache set中的valid_bit位
 * 当前访问的cache_line的valid_bit位会被置1
 * valid_bit为0的保持不变
 * valid_bit>0的将加一(除了当前访问的cache_line)
*/
void setValidBit(cache_line *cset, cache_line *cl){
    cl->valid_bit=1;
    for(int i=0;i<E;i++){
        if(&cset[i]!=cl && cset[i].valid_bit>0){
            cset[i].valid_bit++;
        }
    }
}

/*
 * getFreeCacheLine(): 获取cache set中valid_bit为0的cache_line
*/
cache_line *getFreeCacheLine(cache_line *cset){
    for(int i=0;i<E;i++){
        if(cset[i].valid_bit==0)
            return &cset[i];
    }
    return NULL;
}

/*
 * evict(): 淘汰一个cache_line，least-recently used策略
 * 淘汰valid_bit最大的cache_line
*/
cache_line *evict(cache_line * cset){
    cache_line *cl=cset;
    for(int i=1;i<E;i++){
        if(cl->valid_bit<cset[i].valid_bit)
            cl=&cset[i];
    }
    return cl;
}

/*
 * cacheOption(): cache操作
*/
void cacheOption(cache_line (*cache)[E], RunMode rm, long adr){
    /* 获取tag_bit, set_bit */
    long tag_bit=GETBIT(tag_mask, adr);
    long set_bit=GETBIT(set_mask, adr);
    /* 计算set索引 */
    int setNum=(int)(set_bit>>b);
    cache_line *cl;
    /* 通过setNum和tag_bit访问cache */
    if((cl=accessCache(cache[setNum], tag_bit))!=NULL){
        /* hit */
        if(rm==VERBOSE) printf(" hit");
        hit_cnt++;
        /* 更新当前set中的所有valid_bit */
        setValidBit(cache[setNum], cl);
        return;
    }
    /* miss */
    if(rm==VERBOSE) printf(" miss");
    miss_cnt++;
    /* 查找空闲的cache_line */
    cl=getFreeCacheLine(cache[setNum]);
    if(cl){/* 存在空闲的cache_line则使用空闲cache_line */
        cl->tag_bit=tag_bit;
        /* 更新当前set中的所有valid_bit */
        setValidBit(cache[setNum], cl);
        return;
    }
    /* 不存在空闲的cache_line, 淘汰一个cache_line*/
    if(rm==VERBOSE) printf(" eviction");
    eviction_cnt++;
    cl=evict(cache[setNum]);
    cl->tag_bit=tag_bit;
    /* 更新当前set中的所有valid_bit */
    setValidBit(cache[setNum], cl);
}






